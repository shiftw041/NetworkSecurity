sudo ./vpnserver
sudo ifconfig tun0 192.168.53.1/24 up
